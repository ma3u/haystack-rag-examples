# Book Awards Websearch Agent

## Overview
This agent automatically searches for book awards, extracts detailed information about them, and updates an Airtable base with the collected data. It's designed to maintain a comprehensive database of book awards with all the fields specified in the provided CSV file.

## Features
- Automated web search to discover book awards
- Detailed data extraction from award websites
- Automatic Airtable integration for database updates
- Comprehensive field coverage matching the provided CSV structure
- Data completeness tracking and validation

## Project Structure
```
book_awards_agent/
├── src/
│   ├── config.py           # Configuration settings
│   ├── websearch.py        # Web search functionality
│   ├── extractor.py        # Data extraction from websites
│   ├── airtable_updater.py # Airtable integration
│   └── main.py             # Main coordination script
├── tests/
│   └── test_validation.py  # Validation and testing script
└── README.md               # This documentation
```

## Setup Instructions

### Prerequisites
- Python 3.8 or higher
- An Airtable account with API access
- The following Python packages:
  - requests
  - beautifulsoup4
  - logging

### Installation
1. Clone or download this repository
2. Install required packages:
   ```
   pip install requests beautifulsoup4
   ```
3. Configure your Airtable credentials in `src/config.py` or use environment variables:
   ```python
   # In config.py
   AIRTABLE_API_KEY = "your_api_key"
   AIRTABLE_BASE_ID = "your_base_id"
   AIRTABLE_TABLE_NAME = "Book Awards"
   ```

## Usage

### Basic Usage
Run the agent with default settings:
```
python src/main.py
```

This will:
1. Search for book awards online
2. Extract data from award websites
3. Update your Airtable base with the collected information

### Command Line Options
The agent supports several command line options:

- `--search-only`: Only search for awards without updating Airtable
- `--update-only`: Only update Airtable from existing data file
- `--input-file FILE`: Path to input file with award URLs or data
- `--airtable-api-key KEY`: Airtable API key
- `--airtable-base-id ID`: Airtable base ID
- `--airtable-table-name NAME`: Airtable table name

Examples:
```
# Search only without updating Airtable
python src/main.py --search-only

# Process specific URLs from a file
python src/main.py --input-file urls.txt

# Update Airtable from existing data file
python src/main.py --update-only --input-file book_awards_data.json
```

### Environment Variables
Instead of modifying the config file, you can set environment variables:
```
export AIRTABLE_API_KEY="your_api_key"
export AIRTABLE_BASE_ID="your_base_id"
export AIRTABLE_TABLE_NAME="Book Awards"
```

## Data Fields
The agent collects the following information for each book award:

- Award Name
- Category
- Entry Deadline
- Eligibility Criteria
- Application Procedures
- Award Website
- Prize Amount
- Application Fee
- Award Status
- Award Logo
- Awarding Organization
- Contact Information (Person, Email, Phone, Address)
- Past Winners URL
- Extra Benefits
- In-Person Celebration
- Number of Categories
- Geographic Restrictions
- Accepted Formats
- ISBN Required
- Judging Criteria
- And many more fields matching the provided CSV structure

## Testing and Validation
Run the validation script to test the agent's functionality:
```
python tests/test_validation.py
```

This will:
1. Test the websearch functionality
2. Test data extraction with sample URLs
3. Validate data completeness
4. Test Airtable integration (if credentials are provided)

## Customization
You can customize the agent's behavior by modifying the following files:

- `config.py`: Adjust search queries, field definitions, and other settings
- `websearch.py`: Modify search behavior and result filtering
- `extractor.py`: Enhance data extraction patterns for specific fields
- `airtable_updater.py`: Customize Airtable integration logic

## Troubleshooting
- If the agent fails to find book awards, try modifying the search queries in `config.py`
- If data extraction is incomplete, check the extraction patterns in `extractor.py`
- For Airtable integration issues, verify your API credentials and table structure

## Limitations
- The agent relies on website structure for data extraction, which may change over time
- Some fields may require manual verification for complete accuracy
- Rate limiting may affect the number of awards that can be processed in a single run
